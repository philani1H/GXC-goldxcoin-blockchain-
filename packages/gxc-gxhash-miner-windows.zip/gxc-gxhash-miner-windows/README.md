# GXC GxHash Miner

CPU miner for GXC blockchain using GxHash algorithm.

## Features
- Real blockchain connection
- CPU mining with GxHash algorithm
- Modern GUI with live stats
- Multi-threaded mining

## Install
```bash
chmod +x install.sh
./install.sh
```

## Run
```bash
gxhash-miner
```

## License
MIT License - Mining involves financial risk.
