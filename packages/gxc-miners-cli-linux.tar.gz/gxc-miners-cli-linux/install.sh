#!/bin/bash
echo "Installing GXC Command-Line Miners..."
echo ""

# Make all executables
chmod +x gxc-*

echo "✅ Installation complete!"
echo ""
echo "Miners are ready to use. See README.md for usage instructions."
